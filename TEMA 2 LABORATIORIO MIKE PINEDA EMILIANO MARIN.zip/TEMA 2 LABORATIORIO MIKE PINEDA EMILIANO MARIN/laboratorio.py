def leer_usuarios():
    lista_usuarios = []
    try:
        archivo = open("usuarios.csv", "r")
        lineas = archivo.readlines()
        archivo.close()
        for i in range(1, len(lineas), 1):
            linea = lineas[i].strip()
            if linea != "":
                partes = linea.split(",")
                if len(partes) >= 3:
                    u = {
                        "usuario": partes[0].strip(),
                        "clave": partes[1].strip(),
                        "rol": partes[2].strip().upper()
                    }
                    lista_usuarios.append(u)
    except FileNotFoundError:
        raise FileNotFoundError("Error: No se encontró el archivo usuarios.csv.")
    except ValueError as ve:
        raise ValueError(f"Error numérico en usuarios.csv: {ve}")
    except IndexError as ie:
        raise IndexError(f"Error de formato en usuarios.csv: {ie}")
    return lista_usuarios

def leer_puestos():
    lista_puestos = []
    try:
        archivo = open("puestos.csv", "r")
        lineas = archivo.readlines()
        archivo.close()
        for i in range(1, len(lineas), 1):
            linea = lineas[i].strip()
            if linea != "":
                partes = linea.split(",")
                if len(partes) >= 2:
                    m_id = ""
                    if len(partes) >= 3:
                        m_id = partes[2].strip()
                    p = {
                        "puesto": partes[0].strip().upper(),
                        "estado": partes[1].strip().upper(),
                        "muestra_id": m_id
                    }
                    lista_puestos.append(p)
    except FileNotFoundError:
        raise FileNotFoundError("Error: No se encontró el archivo puestos.csv.")
    except ValueError as ve:
        raise ValueError(f"Error numérico en puestos.csv: {ve}")
    except IndexError as ie:
        raise IndexError(f"Error de formato en puestos.csv: {ie}")
    return lista_puestos

def guardar_puestos(lista_puestos):
    try:
        archivo = open("puestos.csv", "w")
        archivo.write("puesto,estado,muestra_id\n")
        for p in lista_puestos:
            archivo.write(f"{p['puesto']},{p['estado']},{p['muestra_id']}\n")
        archivo.close()
        return True
    except FileNotFoundError:
        raise FileNotFoundError("Error: No se encontró el archivo puestos.csv para guardar.")

def leer_limites():
    dict_limites = {}
    try:
        archivo = open("limites.csv", "r")
        lineas = archivo.readlines()
        archivo.close()
        for i in range(1, len(lineas), 1):
            linea = lineas[i].strip()
            if linea != "":
                partes = linea.split(",")
                if len(partes) >= 2:
                    tipo = partes[0].strip().upper()
                    limite_valor = float(partes[1].strip())
                    dict_limites[tipo] = limite_valor
    except FileNotFoundError:
        raise FileNotFoundError("Error: No se encontró el archivo limites.csv.")
    except ValueError as ve:
        raise ValueError(f"Error numérico en limites.csv: {ve}")
    except IndexError as ie:
        raise IndexError(f"Error de formato en limites.csv: {ie}")
    return dict_limites

def leer_muestras():
    lista_muestras = []
    try:
        archivo = open("muestras.csv", "r")
        lineas = archivo.readlines()
        archivo.close()
        for i in range(1, len(lineas), 1):
            linea = lineas[i].strip()
            if linea != "":
                partes = linea.split(",")
                if len(partes) >= 5:
                    m = {
                        "muestra_id": partes[0].strip().upper(),
                        "fecha_hora": partes[1].strip(),
                        "tipo_muestra": partes[2].strip().upper(),
                        "prioridad": int(partes[3].strip()),
                        "estado": partes[4].strip().upper(),
                        "analista": partes[5].strip() if len(partes) > 5 else "",
                        "puesto": partes[6].strip().upper() if len(partes) > 6 else "",
                        "resultado": partes[7].strip() if len(partes) > 7 else "",
                        "alerta": partes[8].strip().upper() if len(partes) > 8 else ""
                    }
                    lista_muestras.append(m)
    except FileNotFoundError:
        raise FileNotFoundError("Error: No se encontró el archivo muestras.csv.")
    except ValueError as ve:
        raise ValueError(f"Error numérico en muestras.csv: {ve}")
    except IndexError as ie:
        raise IndexError(f"Error de formato en muestras.csv: {ie}")
    return lista_muestras

def guardar_muestras(lista_muestras):
    try:
        archivo = open("muestras.csv", "w")
        archivo.write("muestra_id,fecha_hora,tipo_muestra,prioridad,estado,analista,puesto,resultado,alerta\n")
        for m in lista_muestras:
            linea = f"{m['muestra_id']},{m['fecha_hora']},{m['tipo_muestra']},{m['prioridad']},{m['estado']},{m['analista']},{m['puesto']},{m['resultado']},{m['alerta']}\n"
            archivo.write(linea)
        archivo.close()
        return True
    except FileNotFoundError:
        raise FileNotFoundError("Error: No se encontró el archivo muestras.csv para guardar.")

def leer_mediciones():
    lista_mediciones = []
    try:
        archivo = open("mediciones.csv", "r")
        lineas = archivo.readlines()
        archivo.close()
        for i in range(1, len(lineas), 1):
            linea = lineas[i].strip()
            if linea != "":
                partes = linea.split(",")
                if len(partes) >= 4:
                    reg = {
                        "muestra_id": partes[0].strip().upper(),
                        "fecha_hora": partes[1].strip(),
                        "usuario": partes[2].strip(),
                        "valor_ntu": float(partes[3].strip())
                    }
                    lista_mediciones.append(reg)
    except FileNotFoundError:
        raise FileNotFoundError("Error: No se encontró el archivo mediciones.csv.")
    except ValueError as ve:
        raise ValueError(f"Error numérico en mediciones.csv: {ve}")
    except IndexError as ie:
        raise IndexError(f"Error de formato en mediciones.csv: {ie}")
    return lista_mediciones

def registrar_medicion_archivo(muestra_id, fecha_hora, usuario, valor_ntu):
    try:
        archivo = open("mediciones.csv", "a")
        archivo.write(f"{muestra_id},{fecha_hora},{usuario},{valor_ntu}\n")
        archivo.close()
        return True
    except FileNotFoundError:
        raise FileNotFoundError("Error: No se encontró el archivo mediciones.csv para registrar medición.")

def calcular_discrepancia(m1, m2):
    if m1 == 0.0 and m2 == 0.0:
        return 0.0
    promedio = (m1 + m2) / 2.0
    diferencia = m1 - m2
    if diferencia < 0:
        diferencia = -diferencia
    discrepancia = (100.0 * diferencia) / promedio
    return round(discrepancia, 2)

def calcular_mediana_tres(m1, m2, m3):
    lista_valores = [m1, m2, m3]
    for i in range(0, len(lista_valores), 1):
        for j in range(0, len(lista_valores) - 1, 1):
            if lista_valores[j] > lista_valores[j + 1]:
                temp = lista_valores[j]
                lista_valores[j] = lista_valores[j + 1]
                lista_valores[j + 1] = temp
    return lista_valores[1]

def ordenar_cola_pendientes(vector_muestras):
    cola = []
    for i in range(0, len(vector_muestras), 1):
        m = vector_muestras[i]
        if m["estado"] != "VALIDADA" and m["estado"] != "ARCHIVADA":
            cola.append(m)
    for i in range(0, len(cola), 1):
        for j in range(0, len(cola) - 1, 1):
            elem1 = cola[j]
            elem2 = cola[j + 1]
            intercambiar = False
            if elem1["prioridad"] > elem2["prioridad"]:
                intercambiar = True
            elif elem1["prioridad"] == elem2["prioridad"]:
                if elem1["fecha_hora"] > elem2["fecha_hora"]:
                    intercambiar = True
                elif elem1["fecha_hora"] == elem2["fecha_hora"]:
                    if elem1["muestra_id"] > elem2["muestra_id"]:
                        intercambiar = True
            if intercambiar:
                cola[j] = elem2 
                cola[j + 1] = elem1
    return cola

def buscar_muestra_por_id(vector_muestras, muestra_id):
    for i in range(0, len(vector_muestras), 1):
        if vector_muestras[i]["muestra_id"] == muestra_id.upper():
            return vector_muestras[i]
    return {}

def buscar_puesto_por_id(vector_puestos, puesto_id):
    for i in range(0, len(vector_puestos), 1):
        if vector_puestos[i]["puesto"] == puesto_id.upper():
            return vector_puestos[i]
    return {}

def login_usuario(usuario_activo, rol_activo):
    lista_usuarios = leer_usuarios()
    if len(lista_usuarios) == 0:
        raise ValueError("No hay usuarios registrados en el sistema.")

    if usuario_activo != "":
        cerrar_msg = f"\nSesión actualmente activa: {usuario_activo} (Rol: {rol_activo})\n"
        while True:
            opcion = input(cerrar_msg + "¿Deseas cerrar tu sesión actual? |1.SI | 2.NO | -> ").strip()
            if opcion == "1":
                usuario_prev = usuario_activo
                usuario_activo = ""
                rol_activo = ""
                cambiar = input(f"Sesión cerrada. ¡Hasta luego {usuario_prev}!\n¿Deseas iniciar sesión con otra cuenta ahora? |1.SI | 2.NO | -> ").strip()
                if cambiar == "1":
                    break
                else:
                    return "", "", f"Sesión cerrada. ¡Hasta luego {usuario_prev}!"
            elif opcion == "2":
                return usuario_activo, rol_activo, "Operación cancelada. Sesión mantenida."
            else:
                cerrar_msg = "DATO INVALIDO\n"

    nombre_usuario = input("\n--- INICIO DE SESIÓN EN LABORATORIO ---\nIngresa tu usuario -> ").strip()
    clave_usuario = input("Ingresa tu clave -> ").strip()

    for i in range(0, len(lista_usuarios), 1):
        u = lista_usuarios[i]
        if u["usuario"] == nombre_usuario and u["clave"] == clave_usuario:
            return u["usuario"], u["rol"], f"¡Bienvenido/a {u['usuario']}! Rol asignado: {u['rol']}"

    raise ValueError("ERROR: Usuario o contraseña incorrectos.")

def opcion_registrar_muestra(usuario_activo, rol_activo):
    if rol_activo != "ADMIN":
        raise ValueError("Acceso denegado: solo el rol ADMIN puede registrar nuevas muestras.")

    vector_muestras = leer_muestras()
    dict_limites = leer_limites()

    encabezado = "\n==================================================\n"
    encabezado += "REGISTRAR NUEVA MUESTRA AMBIENTAL\n"
    encabezado += "==================================================\n"

    num_consecutivo = len(vector_muestras) + 1
    id_sugerido = f"M{str(num_consecutivo).zfill(3)}"

    muestra_id = input(encabezado + f"Ingresa el ID de la muestra [Enter para '{id_sugerido}'] -> ").strip().upper()
    if muestra_id == "":
        muestra_id = id_sugerido

    existe = buscar_muestra_por_id(vector_muestras, muestra_id)
    if len(existe) > 0:
        raise ValueError("ERROR: Ya existe una muestra registrada con ese identificador.")

    tipos_str = "Tipos de muestra disponibles:\n"
    for t in dict_limites.keys():
        tipos_str += f"- {t} (Límite: {dict_limites[t]} NTU)\n"

    tipo_muestra = input(tipos_str + "Ingresa el tipo de muestra -> ").strip().upper()
    if tipo_muestra not in dict_limites:
        raise ValueError("ERROR: Tipo de muestra no reconocido en la tabla de límites.")

    prioridad = 0
    prio_prompt = "Ingresa la prioridad | 1 (Alta) | 2 (Media) | 3 (Baja) | -> "
    while True:
        prio_input = input(prio_prompt).strip()
        if prio_input.isdigit():
            prioridad = int(prio_input)
            if 1 <= prioridad <= 3:
                break
            else:
                prio_prompt = "Dato invalido: la prioridad debe ser 1, 2 o 3.\nIngresa la prioridad | 1 (Alta) | 2 (Media) | 3 (Baja) | -> "
        else:
            prio_prompt = "DATO INVALIDO\nIngresa la prioridad | 1 (Alta) | 2 (Media) | 3 (Baja) | -> "

    fecha_hora = input("Ingresa fecha y hora (YYYY-MM-DD HH:MM) [Enter para '2026-11-10 08:00'] -> ").strip()
    if fecha_hora == "":
        fecha_hora = "2026-11-10 08:00"

    nueva_muestra = {
        "muestra_id": muestra_id,
        "fecha_hora": fecha_hora,
        "tipo_muestra": tipo_muestra,
        "prioridad": prioridad,
        "estado": "REGISTRADA",
        "analista": "",
        "puesto": "",
        "resultado": "",
        "alerta": ""
    }

    vector_muestras.append(nueva_muestra)
    guardar_muestras(vector_muestras)
    return f"Muestra {muestra_id} registrada exitosamente en estado REGISTRADA."

def opcion_ver_pendientes():
    vector_muestras = leer_muestras()
    cola = ordenar_cola_pendientes(vector_muestras)

    texto = "\n==========================================================================\n"
    texto += "COLA DE MUESTRAS PENDIENTES (ORDEN: PRIORIDAD ASC, FECHA/HORA ASC, ID ASC)\n"
    texto += "==========================================================================\n"
    if len(cola) == 0:
        texto += "No hay muestras pendientes por procesar.\n"
        return texto

    texto += "{:<10} {:<18} {:<12} {:<10} {:<22} {:<10} {:<10}\n".format(
        "ID", "FECHA/HORA", "TIPO", "PRIORIDAD", "ESTADO", "PUESTO", "ANALISTA")
    texto += "-" * 95 + "\n"
    for i in range(0, len(cola), 1):
        m = cola[i]
        puesto_str = m["puesto"] if m["puesto"] != "" else "N/A"
        analista_str = m["analista"] if m["analista"] != "" else "N/A"
        texto += "{:<10} {:<18} {:<12} {:<10} {:<22} {:<10} {:<10}\n".format(
            m["muestra_id"], m["fecha_hora"], m["tipo_muestra"], m["prioridad"], m["estado"], puesto_str, analista_str)
    texto += "-" * 95
    return texto

def opcion_asignar_puesto(usuario_activo, rol_activo):
    if rol_activo != "ANALISTA":
        raise ValueError("Acceso denegado: solo el rol ANALISTA puede asignar puestos a muestras.")

    vector_muestras = leer_muestras()
    vector_puestos = leer_puestos()

    muestras_disponibles = []
    for i in range(0, len(vector_muestras), 1):
        if vector_muestras[i]["estado"] == "REGISTRADA":
            muestras_disponibles.append(vector_muestras[i])

    if len(muestras_disponibles) == 0:
        raise ValueError("No hay muestras en estado REGISTRADA esperando asignación.")

    puestos_libres = []
    puestos_str = "\nPuestos de trabajo registrados:\n"
    for i in range(0, len(vector_puestos), 1):
        p = vector_puestos[i]
        puestos_str += f"- Puesto: {p['puesto']} | Estado: {p['estado']} | Muestra: {p['muestra_id']}\n"
        if p["estado"] == "LIBRE":
            puestos_libres.append(p["puesto"])

    if len(puestos_libres) == 0:
        raise ValueError("No hay puestos de trabajo LIBRES en este momento.")

    info_str = "\n--- ASIGNACIÓN DE PUESTO DE TRABAJO A MUESTRA ---\n"
    info_str += "Muestras disponibles para asignar:\n"
    for i in range(0, len(muestras_disponibles), 1):
        m = muestras_disponibles[i]
        info_str += f"- ID: {m['muestra_id']} | Tipo: {m['tipo_muestra']} | Prioridad: {m['prioridad']}\n"
    info_str += puestos_str

    id_muestra_input = input(info_str + "\nIngresa el ID de la muestra a asignar -> ").strip().upper()
    muestra_encontrada = buscar_muestra_por_id(vector_muestras, id_muestra_input)
    if len(muestra_encontrada) == 0:
        raise ValueError("ERROR: La muestra no existe en el sistema.")

    if muestra_encontrada["estado"] != "REGISTRADA":
        raise ValueError(f"Operación rechazada: La muestra está en estado '{muestra_encontrada['estado']}'. Solo se pueden asignar muestras REGISTRADAS.")

    id_puesto_input = input("Ingresa el puesto a asignar -> ").strip().upper()
    puesto_encontrado = buscar_puesto_por_id(vector_puestos, id_puesto_input)
    if len(puesto_encontrado) == 0:
        raise ValueError("ERROR: El puesto indicado no existe.")

    if puesto_encontrado["estado"] != "LIBRE":
        raise ValueError("Operación rechazada: El puesto seleccionado se encuentra OCUPADO.")

    muestra_encontrada["estado"] = "EN_ANALISIS"
    muestra_encontrada["puesto"] = id_puesto_input
    muestra_encontrada["analista"] = usuario_activo

    puesto_encontrado["estado"] = "OCUPADO"
    puesto_encontrado["muestra_id"] = id_muestra_input

    guardar_muestras(vector_muestras)
    guardar_puestos(vector_puestos)
    return f"Muestra {id_muestra_input} asignada al puesto {id_puesto_input} por el analista {usuario_activo}."

def opcion_registrar_mediciones(usuario_activo, rol_activo):
    if rol_activo != "ANALISTA":
        raise ValueError("Acceso denegado: solo el rol ANALISTA puede registrar mediciones.")

    vector_muestras = leer_muestras()
    muestras_en_analisis = []
    for i in range(0, len(vector_muestras), 1):
        if vector_muestras[i]["estado"] == "EN_ANALISIS":
            muestras_en_analisis.append(vector_muestras[i])

    if len(muestras_en_analisis) == 0:
        raise ValueError("No hay muestras en estado EN_ANALISIS para registrar lecturas.")

    info_str = "\n--- REGISTRO DE MEDICIONES DE TURBIDEZ (NTU) ---\n"
    for i in range(0, len(muestras_en_analisis), 1):
        m = muestras_en_analisis[i]
        info_str += f"- ID: {m['muestra_id']} | Tipo: {m['tipo_muestra']} | Puesto: {m['puesto']} | Analista: {m['analista']}\n"

    id_muestra_input = input(info_str + "\nIngresa el ID de la muestra a medir -> ").strip().upper()
    muestra = buscar_muestra_por_id(vector_muestras, id_muestra_input)
    if len(muestra) == 0:
        raise ValueError("ERROR: Muestra inexistente.")

    if muestra["estado"] != "EN_ANALISIS":
        raise ValueError(f"Operación rechazada: La muestra está en estado '{muestra['estado']}'. Solo se pueden registrar mediciones en muestras EN_ANALISIS.")

    fecha_medicion = input("Ingresa fecha y hora de la medición (YYYY-MM-DD HH:MM) [Enter para '2026-11-10 09:00'] -> ").strip()
    if fecha_medicion == "":
        fecha_medicion = "2026-11-10 09:00"

    m1 = -1.0
    prompt_m1 = "Ingresa la lectura 1 (NTU) -> "
    while m1 < 0.0:
        val_str = input(prompt_m1).strip()
        try:
            m1 = float(val_str)
            if m1 < 0.0:
                prompt_m1 = "Dato inválido: la turbidez no puede ser negativa.\nIngresa la lectura 1 (NTU) -> "
        except ValueError:
            prompt_m1 = "DATO INVALIDO: debe ser un número decimal o entero.\nIngresa la lectura 1 (NTU) -> "

    m2 = -1.0
    prompt_m2 = "Ingresa la lectura 2 (NTU) -> "
    while m2 < 0.0:
        val_str = input(prompt_m2).strip()
        try:
            m2 = float(val_str)
            if m2 < 0.0:
                prompt_m2 = "Dato inválido: la turbidez no puede ser negativa.\nIngresa la lectura 2 (NTU) -> "
        except ValueError:
            prompt_m2 = "DATO INVALIDO: debe ser un número decimal o entero.\nIngresa la lectura 2 (NTU) -> "

    registrar_medicion_archivo(muestra["muestra_id"], fecha_medicion, usuario_activo, m1)
    registrar_medicion_archivo(muestra["muestra_id"], fecha_medicion, usuario_activo, m2)

    discrepancia = calcular_discrepancia(m1, m2)
    salida_texto = f"Discrepancia calculada: {discrepancia}%\n"

    resultado_final = 0.0
    if discrepancia > 10.0:
        prompt_m3 = "¡Alerta de consistencia! La discrepancia supera el 10%. Se exige una TERCERA lectura.\nIngresa la lectura 3 (NTU) -> "
        m3 = -1.0
        while m3 < 0.0:
            val_str = input(prompt_m3).strip()
            try:
                m3 = float(val_str)
                if m3 < 0.0:
                    prompt_m3 = "Dato inválido: la turbidez no puede ser negativa.\nIngresa la lectura 3 (NTU) -> "
            except ValueError:
                prompt_m3 = "DATO INVALIDO\nIngresa la lectura 3 (NTU) -> "

        registrar_medicion_archivo(muestra["muestra_id"], fecha_medicion, usuario_activo, m3)
        resultado_final = calcular_mediana_tres(m1, m2, m3)
        salida_texto += f"Mediana de las tres lecturas [{m1}, {m2}, {m3}]: {resultado_final} NTU\n"
    else:
        if m1 == 0.0 and m2 == 0.0:
            resultado_final = 0.0
        else:
            resultado_final = round((m1 + m2) / 2.0, 2)
        salida_texto += f"Promedio de las dos lecturas [{m1}, {m2}]: {resultado_final} NTU\n"

    muestra["estado"] = "PENDIENTE_VALIDACION"
    muestra["resultado"] = str(round(resultado_final, 2))
    guardar_muestras(vector_muestras)
    salida_texto += f"Muestra {muestra['muestra_id']} actualizada a PENDIENTE_VALIDACION con resultado {resultado_final} NTU."
    return salida_texto

def opcion_validar_resultado(usuario_activo, rol_activo):
    if rol_activo != "SUPERVISOR":
        raise ValueError("Acceso denegado: solo el rol SUPERVISOR puede validar resultados.")

    vector_muestras = leer_muestras()
    vector_puestos = leer_puestos()
    dict_limites = leer_limites()

    pendientes = []
    for i in range(0, len(vector_muestras), 1):
        if vector_muestras[i]["estado"] == "PENDIENTE_VALIDACION":
            pendientes.append(vector_muestras[i])

    if len(pendientes) == 0:
        raise ValueError("No hay muestras en estado PENDIENTE_VALIDACION.")

    info_str = "\n--- VALIDACIÓN DE RESULTADOS POR SUPERVISIÓN ---\n"
    info_str += "Muestras pendientes de validación:\n"
    for i in range(0, len(pendientes), 1):
        m = pendientes[i]
        lim = dict_limites.get(m["tipo_muestra"], 0.0)
        info_str += f"- ID: {m['muestra_id']} | Tipo: {m['tipo_muestra']} | Resultado: {m['resultado']} NTU | Límite: {lim} NTU | Puesto: {m['puesto']}\n"

    id_muestra_input = input(info_str + "\nIngresa el ID de la muestra a validar -> ").strip().upper()
    muestra = buscar_muestra_por_id(vector_muestras, id_muestra_input)
    if len(muestra) == 0:
        raise ValueError("ERROR: Muestra inexistente.")

    if muestra["estado"] != "PENDIENTE_VALIDACION":
        raise ValueError(f"Operación rechazada: La muestra está en estado '{muestra['estado']}'. No se puede validar una muestra sin mediciones completas.")

    val_resultado = float(muestra["resultado"])
    limite_tipo = dict_limites.get(muestra["tipo_muestra"], 0.0)

    salida_texto = ""
    alerta_estado = "NORMAL"
    if val_resultado > limite_tipo:
        alerta_estado = "ALERTA"
        salida_texto += f"¡ATENCIÓN! Resultado ({val_resultado} NTU) supera el límite permitido ({limite_tipo} NTU). Marcada como ALERTA.\n"
    else:
        salida_texto += f"Resultado ({val_resultado} NTU) dentro del límite regulatorio ({limite_tipo} NTU). Marcada como NORMAL.\n"

    muestra["estado"] = "VALIDADA"
    muestra["alerta"] = alerta_estado

    puesto_asociado = muestra["puesto"]
    if puesto_asociado != "":
        p = buscar_puesto_por_id(vector_puestos, puesto_asociado)
        if len(p) > 0:
            p["estado"] = "LIBRE"
            p["muestra_id"] = ""
            guardar_puestos(vector_puestos)
            salida_texto += f"Puesto {puesto_asociado} liberado exitosamente.\n"

    guardar_muestras(vector_muestras)
    salida_texto += f"Muestra {muestra['muestra_id']} validada con éxito por el supervisor {usuario_activo}."
    return salida_texto

def opcion_historial_archivar(usuario_activo, rol_activo):
    vector_muestras = leer_muestras()
    vector_mediciones = leer_mediciones()

    menu_str = "\n==================================================\n"
    menu_str += "HISTORIAL DE MUESTRAS Y ARCHIVADO\n"
    menu_str += "==================================================\n"
    menu_str += "1. Ver listado general de todas las muestras\n"
    menu_str += "2. Ver bitácora completa de mediciones\n"
    menu_str += "3. Archivar muestra validada (Solo ADMIN)\n"
    sub_opcion = input(menu_str + "Selecciona una opción | 1 | 2 | 3 | -> ").strip()

    if sub_opcion == "1":
        salida = "\n{:<8} {:<18} {:<10} {:<6} {:<22} {:<10} {:<8} {:<10} {:<8}\n".format(
            "ID", "FECHA/HORA", "TIPO", "PRIO", "ESTADO", "ANALISTA", "PUESTO", "RESULTADO", "ALERTA")
        salida += "-" * 110 + "\n"
        for i in range(0, len(vector_muestras), 1):
            m = vector_muestras[i]
            res_str = m["resultado"] if m["resultado"] != "" else "N/A"
            ale_str = m["alerta"] if m["alerta"] != "" else "N/A"
            pue_str = m["puesto"] if m["puesto"] != "" else "N/A"
            ana_str = m["analista"] if m["analista"] != "" else "N/A"
            salida += "{:<8} {:<18} {:<10} {:<6} {:<22} {:<10} {:<8} {:<10} {:<8}\n".format(
                m["muestra_id"], m["fecha_hora"], m["tipo_muestra"], m["prioridad"], m["estado"], ana_str, pue_str, res_str, ale_str)
        salida += "-" * 110
        return salida

    elif sub_opcion == "2":
        salida = "\n{:<10} {:<18} {:<15} {:<10}\n".format("MUESTRA", "FECHA/HORA", "USUARIO", "VALOR NTU")
        salida += "-" * 60 + "\n"
        for i in range(0, len(vector_mediciones), 1):
            med = vector_mediciones[i]
            salida += "{:<10} {:<18} {:<15} {:<10}\n".format(med["muestra_id"], med["fecha_hora"], med["usuario"], med["valor_ntu"])
        salida += "-" * 60
        return salida

    elif sub_opcion == "3":
        if rol_activo != "ADMIN":
            raise ValueError("Acceso denegado: solo el rol ADMIN tiene permiso para archivar muestras.")

        validadas = []
        for i in range(0, len(vector_muestras), 1):
            if vector_muestras[i]["estado"] == "VALIDADA":
                validadas.append(vector_muestras[i])

        if len(validadas) == 0:
            raise ValueError("No hay muestras en estado VALIDADA disponibles para archivar.")

        valid_str = "\nMuestras en estado VALIDADA aptas para archivo definitivo:\n"
        for i in range(0, len(validadas), 1):
            m = validadas[i]
            valid_str += f"- ID: {m['muestra_id']} | Tipo: {m['tipo_muestra']} | Resultado: {m['resultado']} | Alerta: {m['alerta']}\n"

        id_arch = input(valid_str + "Ingresa el ID de la muestra a archivar -> ").strip().upper()
        m_target = buscar_muestra_por_id(vector_muestras, id_arch)
        if len(m_target) == 0:
            raise ValueError("ERROR: Muestra no encontrada.")

        if m_target["estado"] != "VALIDADA":
            raise ValueError(f"Operación rechazada: la muestra está en estado '{m_target['estado']}'. Solo se pueden archivar muestras en estado VALIDADA.")

        m_target["estado"] = "ARCHIVADA"
        guardar_muestras(vector_muestras)
        return f"Muestra {id_arch} archivada exitosamente."

    else:
        raise ValueError("DATO INVALIDO")

def opcion_generar_reportes():
    vector_muestras = leer_muestras()
    dict_limites = leer_limites()

    salida_texto = "\n==================================================\n"
    salida_texto += "REPORTES DE CALIDAD Y CONTROL DEL LABORATORIO\n"
    salida_texto += "==================================================\n"

    validadas = []
    for i in range(0, len(vector_muestras), 1):
        m = vector_muestras[i]
        if m["estado"] == "VALIDADA" or m["estado"] == "ARCHIVADA":
            validadas.append(m)

    salida_texto += "\n1. MUESTRAS VALIDADAS CON ALERTA POR TIPO:\n"
    salida_texto += "{:<12} {:<12} {:<12} {:<10}\n".format("TIPO", "TOTAL VAL.", "CON ALERTA", "% ALERTA")
    salida_texto += "-" * 50 + "\n"

    lineas_resumen_txt = []
    lineas_resumen_txt.append("==================================================\n")
    lineas_resumen_txt.append("INFORME DE CONTROL DE CALIDAD - LABORATORIO\n")
    lineas_resumen_txt.append("==================================================\n\n")
    lineas_resumen_txt.append("1. RESUMEN DE ALERTAS POR TIPO DE MUESTRA:\n")

    alertas_csv_lineas = []
    alertas_csv_lineas.append("muestra_id,tipo_muestra,resultado,limite,alerta\n")

    for tipo in dict_limites.keys():
        total_tipo = 0
        alertas_tipo = 0
        for i in range(0, len(validadas), 1):
            m = validadas[i]
            if m["tipo_muestra"] == tipo:
                total_tipo += 1
                if m["alerta"] == "ALERTA":
                    alertas_tipo += 1

        porcentaje = 0.0
        if total_tipo > 0:
            porcentaje = round((alertas_tipo * 100.0) / total_tipo, 2)
            porc_str = f"{porcentaje}%"
        else:
            porc_str = "0.0%"

        salida_texto += "{:<12} {:<12} {:<12} {:<10}\n".format(tipo, total_tipo, alertas_tipo, porc_str)
        lineas_resumen_txt.append(f"Tipo: {tipo} | Total: {total_tipo} | Alertas: {alertas_tipo} ({porc_str})\n")

    salida_texto += "\n2. PROMEDIO DE NTU FINAL POR TIPO (SOLO VALIDADAS):\n"
    salida_texto += "{:<12} {:<20}\n".format("TIPO", "PROMEDIO NTU")
    salida_texto += "-" * 35 + "\n"
    lineas_resumen_txt.append("\n2. PROMEDIO DE TURBIDEZ (NTU):\n")

    for tipo in dict_limites.keys():
        suma_ntu = 0.0
        conteo_tipo = 0
        for i in range(0, len(validadas), 1):
            m = validadas[i]
            if m["tipo_muestra"] == tipo and m["resultado"] != "":
                try:
                    suma_ntu += float(m["resultado"])
                    conteo_tipo += 1
                except ValueError:
                    pass

        if conteo_tipo > 0:
            prom_ntu = round(suma_ntu / conteo_tipo, 2)
            salida_texto += "{:<12} {:<20}\n".format(tipo, f"{prom_ntu} NTU")
            lineas_resumen_txt.append(f"Tipo {tipo}: {prom_ntu} NTU (sobre {conteo_tipo} muestras)\n")
        else:
            salida_texto += "{:<12} {:<20}\n".format(tipo, "sin datos")
            lineas_resumen_txt.append(f"Tipo {tipo}: sin datos\n")

    salida_texto += "\n3. PROCESAMIENTO POR ANALISTA:\n"
    analistas_dict = {}
    for i in range(0, len(vector_muestras), 1):
        m = vector_muestras[i]
        if m["analista"] != "":
            analistas_dict[m["analista"]] = analistas_dict.get(m["analista"], 0) + 1

    if len(analistas_dict) == 0:
        salida_texto += "Ninguna muestra ha sido procesada por analistas aún.\n"
        lineas_resumen_txt.append("\n3. ANALISTAS: Ninguna muestra procesada aún.\n")
    else:
        for ana, cant in analistas_dict.items():
            salida_texto += f"- Analista '{ana}': {cant} muestra(s) procesada(s)\n"
            lineas_resumen_txt.append(f"- Analista {ana}: {cant} muestra(s)\n")

    for i in range(0, len(vector_muestras), 1):
        m = vector_muestras[i]
        if m["alerta"] == "ALERTA":
            lim = dict_limites.get(m["tipo_muestra"], 0.0)
            alertas_csv_lineas.append(f"{m['muestra_id']},{m['tipo_muestra']},{m['resultado']},{lim},{m['alerta']}\n")

    try:
        arch_alertas = open("alertas.csv", "w")
        for linea in alertas_csv_lineas:
            arch_alertas.write(linea)
        arch_alertas.close()
        salida_texto += "\nArchivo de auditoría 'alertas.csv' exportado exitosamente.\n"
    except FileNotFoundError:
        raise FileNotFoundError("Error al exportar alertas.csv: No se encontró la ruta de archivo.")

    try:
        arch_resumen = open("resumen_laboratorio.txt", "w")
        for linea in lineas_resumen_txt:
            arch_resumen.write(linea)
        arch_resumen.close()
        salida_texto += "Informe consolidado 'resumen_laboratorio.txt' exportado exitosamente."
    except FileNotFoundError:
        raise FileNotFoundError("Error al exportar resumen_laboratorio.txt: No se encontró la ruta de archivo.")

    return salida_texto

def menu_principal():
    usuario_activo = ""
    rol_activo = ""
    while True:
        sesion_str = f"Usuario: {usuario_activo} ({rol_activo})" if usuario_activo != "" else "Sin sesión activa (Inicie sesión)"
        print("\n=============== LABORATORIO DE CONTROL AMBIENTAL ===============")
        print(f"Estado de Sesión: {sesion_str}")
        print("1. Iniciar / cerrar sesión")
        print("2. Registrar nueva muestra (ADMIN)")
        print("3. Ver pendientes por prioridad")
        print("4. Asignar puesto a muestra (ANALISTA)")
        print("5. Registrar mediciones (ANALISTA)")
        print("6. Validar resultado y liberar puesto (SUPERVISOR)")
        print("7. Consultar historial / archivar muestra (ADMIN)")
        print("8. Generar reportes de calidad y exportar")
        print("0. Salir")
        print("=================================================================")
        opcion = input("Selecciona una opción -> ").strip()
        try:
            if opcion == "1":
                usuario_activo, rol_activo, msg = login_usuario(usuario_activo, rol_activo)
                if msg != "":
                    print(msg)
            elif opcion == "2":
                msg = opcion_registrar_muestra(usuario_activo, rol_activo)
                if msg != "":
                    print(msg)
            elif opcion == "3":
                msg = opcion_ver_pendientes()
                if msg != "":
                    print(msg)
            elif opcion == "4":
                msg = opcion_asignar_puesto(usuario_activo, rol_activo)
                if msg != "":
                    print(msg)
            elif opcion == "5":
                msg = opcion_registrar_mediciones(usuario_activo, rol_activo)
                if msg != "":
                    print(msg)
            elif opcion == "6":
                msg = opcion_validar_resultado(usuario_activo, rol_activo)
                if msg != "":
                    print(msg)
            elif opcion == "7":
                msg = opcion_historial_archivar(usuario_activo, rol_activo)
                if msg != "":
                    print(msg)
            elif opcion == "8":
                msg = opcion_generar_reportes()
                if msg != "":
                    print(msg)
            elif opcion == "0":
                print("Cerrando sistema de laboratorio ambiental. ¡Hasta pronto!")
                break
            else:
                print("DATO INVALIDO: Por favor ingresa una opción válida del menú.")
        except (ValueError, FileNotFoundError, ZeroDivisionError, IndexError) as err:
            print(f"{err}")

menu_principal()
